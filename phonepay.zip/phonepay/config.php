<?php

           
              $servername   = "localhost";
             $username     = "shopping_shoppinggurushop";
             $password     = "shoppinggurushop@123";
             $dbname       = "shopping_shoppinggurushop_db";
            
            // Create connection
            $conn = new mysqli($servername, $username, $password, $dbname);
            // Check connection
            if ($conn->connect_error) {
              die("Connection failed: " . $conn->connect_error);
            }
            
               $conn->close();

?>