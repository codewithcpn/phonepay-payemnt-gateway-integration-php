    <?php
    ini_set('display_errors', '1');
ini_set('display_startup_errors', '1');
error_reporting(E_ALL);
    
      if(isset($_POST['submit']))
      {
          $name        = $_POST['name'];
          $email       = $_POST['email'];
          $phone       = $_POST['phone'];
          $address     = $_POST['address'];
          $amount      = $_POST['amount'];
          $txn_id      = 'TXN'.rand(10000000,99999999);
          
          
               
               //=======Database connection==================//
               
              $servername   = "localhost";
             $username     = "shopping_shoppinggurushop";
             $password     = "shoppinggurushop@123";
             $dbname       = "shopping_shoppinggurushop_db";
                
                // Create connection
                $conn = new mysqli($servername, $username, $password, $dbname);
                // Check connection
                if ($conn->connect_error) {
                  die("Connection failed: " . $conn->connect_error);
                }
                
               $sql = "INSERT INTO phonepay (name, email, phone, address, amount, customer_trans_id)
                VALUES ('$name', '$email', ' $phone', '$address', ' $amount', '$txn_id')";
              
                
                if (mysqli_query($conn, $sql))
                {
                      echo "";
                }
                else 
                {
                      echo "Error: " . $sql . "<br>" . mysqli_error($conn);
                }
                
                
                $conn->close();
              
          
      
    
    		$salt = '1fd52a49-2d25-44ad-b5b2-0fec267012f9';
    		$salt_index = '1';
    		$payload = [
                  "merchantId"              => "SHOPPINGGURUONLINE",
                  "merchantTransactionId"   => $txn_id,
                  "merchantUserId"          => "SHOPPINGGURUONLINE",
                  "amount"                 => ($amount * 100),
                  "redirectUrl"             => "https://shoppinggurushop.com/phonepay/response.php",
                  "redirectMode"            => "POST",
                  "callbackUrl"             => "https://shoppinggurushop.com/phonepay/update.php",
                  "mobileNumber"            =>  $phone,
                  
    			"paymentInstrument" => [
    				"type" => "PAY_PAGE"
    			]
    		];
    		
    		
    		$base_64dt = base64_encode(json_encode($payload));
    		$enc_request = $base_64dt 	."/pg/v1/pay".$salt;
    		$enc_data = hash('SHA256', $enc_request).'###'.$salt_index;
            $curl = curl_init();
        
       
        
          curl_setopt_array($curl, [
         
          CURLOPT_URL => "https://api.phonepe.com/apis/hermes/pg/v1/pay",
          CURLOPT_RETURNTRANSFER => true,
          CURLOPT_ENCODING => "",
          CURLOPT_MAXREDIRS => 10,
          CURLOPT_TIMEOUT => 30,
          CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
          CURLOPT_CUSTOMREQUEST => "POST",
          CURLOPT_POSTFIELDS => json_encode(["request"=>$base_64dt]),
          CURLOPT_HTTPHEADER => [
            "Content-Type: application/json",
            "X-VERIFY: ".$enc_data,
            "accept: application/json"
          ],
        ]);
        
        $response = curl_exec($curl);
        $err = curl_error($curl);
        $info = curl_getinfo($curl);
        curl_close($curl);
        
        if ($err) 
        {
          echo "cURL Error #:" . $err;
        } 
        else
        {
           echo $response;
             $res = json_decode($response);
             
              if(isset($res->success))
               {
                if($res->success == true)
                 {
                   echo '<script> window.location.href = "'.$res->data->instrumentResponse->redirectInfo->url.'"; </script>';
                 }
                 
               }
        }
    }
        
	?>