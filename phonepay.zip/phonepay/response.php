<!DOCTYPE html>
<html lang="en">
<head>
  <title>shopping Guru Shop -  Payment Details</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/css/bootstrap.min.css" rel="stylesheet">
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/js/bootstrap.bundle.min.js"></script>
</head>
<body>
    
    <?php
    
     $amount                     = $_POST['amount'];
     $totalamount                =  $amount / 100;
     $customer_trans_id          = $_POST['transactionId'];
     $bank_trans_id              = $_POST['providerReferenceId'];
     $status                     = $_POST['code']; 
     $update_on                  = date('Y-m-d H:i:s');
     
     //=======Database connection==================//
               
              $servername   = "localhost";
             $username     = "shopping_shoppinggurushop";
             $password     = "shoppinggurushop@123";
             $dbname       = "shopping_shoppinggurushop_db";
                
                // Create connection
                $conn = new mysqli($servername, $username, $password, $dbname);
                // Check connection
                
                
                $sql = "UPDATE phonepay SET bank_trans_id ='$bank_trans_id', status='$status', update_on='$update_on'  WHERE customer_trans_id='$customer_trans_id'";
                
                
                if (mysqli_query($conn, $sql))
                {
                      echo "";
                }
                else 
                {
                       echo "Error: " . $sql . "<br>" . mysqli_error($conn);
                }
                
                
                $conn->close();
   
      
    ?>
    
     <div class="container mt-5"> 
    <center><img src="https://shoppinggurushop.com/phonepay/assets/img/shoopingguru-removebg-preview.png"></center>
      <table class="table table-bordered mt-3">
        <thead>
          <tr>
            <th>Response Field</th>
            <th>Response Value</th>
          </tr>
        </thead>
        <tbody>
          <tr>
             <td><strong>Amount:</strong></td>
             <td><?php echo $totalamount; ?></td>
          </tr>
           <tr>
             <td><strong>Customer Transaction id:</strong></td>
             <td><?php echo $customer_trans_id; ?></td>
          </tr>
           <tr>
             <td><strong>Bank Transaction id:</strong></td>
             <td><?php echo $bank_trans_id; ?></td>
          </tr>
           <tr>
             <td><strong>Status:</strong></td>
             <td><?php echo $status; ?></td>
          </tr>
        </tbody>
      </table>
      
      <center><a href="https://shoppinggurushop.com/" class="btn btn-lg btn-dark">Back to Home</a></center>
   </div>
    
</body>
</html>
