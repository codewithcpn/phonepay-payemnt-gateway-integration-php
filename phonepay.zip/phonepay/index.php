<!DOCTYPE html>
<html lang="en">
<head>
  <title>Shopping Guru Shop -  Payment Details</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/css/bootstrap.min.css" rel="stylesheet">
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/js/bootstrap.bundle.min.js"></script>
</head>

<body class="bg-warning">
       <center>
            <div class="container mt-5 bg-light rounded pb-5">
             <div class="row">
                 <div class="col-md-8 col-lg-8 col-sm-12">
                      <center><img src="https://shoppinggurushop.com/phonepay/assets/img/shoopingguru-removebg-preview.png"></center>
              <form action="https://shoppinggurushop.com/phonepay/payment.php" method="POST">
                <div class="row mt-5">
                  <div class="col">
                    <label><strong>Amount</strong></label>
                  </div>
                  <div class="col">
                    <input type="text" class="form-control form-control-lg " placeholder="Amount.." name="amount" required="">
                </div>
                </div>
                <div class="row mt-2">
                  <div class="col">
                    <label><strong>Name</strong></label>
                  </div>
                  <div class="col">
                    <input type="text" class="form-control form-control-lg" placeholder="Name.." name="name">
                  </div>
                </div>
                <div class="row mt-2">
                  <div class="col">
                    <label><strong>Email</strong></label>
                  </div>
                  <div class="col">
                    <input type="email" class="form-control form-control-lg" placeholder="Email.." name="email">
                  </div>
                </div>
                <div class="row mt-2">
                  <div class="col">
                    <label><strong>Phone no</strong></label>
                  </div>
                  <div class="col">
                    <input type="number" class="form-control form-control-lg" placeholder="phone no.." name="phone" required="">
                  </div>
                </div>
                <div class="row mt-2">
                  <div class="col">
                    <label><strong>Address</strong></label>
                  </div>
                  <div class="col">
                    <input type="text" class="form-control form-control-lg" placeholder="address" name="address">
                  </div>
                </div>
                <input type="hidden" name="txn_id" value="<?php echo 'TXN'.rand(10000000,99999999)?>">
                <div class="row mt-4">
                  <div class="col">
                    <input type="submit" class="btn btn-warning btn-lg float-end" name="submit" value="Submit">
                  </div>
                  
                </div>
              </form>
                 </div>
             </div>
            </div>
       </center>
       
        
   
</body>
</html>